// OAuth.js

function OAuth ()
{
	this.credentials = {};
}

OAuth.prototype.init = function (key, client_id, client_secret)
{
	this.credentials[key] 	=	'';
}

OAuth.prototype.authorize = function ()
{
		
}